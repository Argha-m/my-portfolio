import React from 'react';
import '../../assets/css/footer.css';

export default class Footer extends React.Component {
    render(props){
        return(
            <footer className="App-footer">
                <p>This my site</p>
            </footer>
        )
    }
}